//For debugging purposes only;
//Strip from build
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerDebugger : MonoBehaviour
{
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
        //Vector3 horizontalVelocity = new Vector3(GetComponent<CharacterController>().velocity.x, 0, GetComponent<CharacterController>().velocity.z);
        //Debug.Log(horizontalVelocity.magnitude);
    }
}
