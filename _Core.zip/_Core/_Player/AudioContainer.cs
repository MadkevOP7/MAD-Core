using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AudioContainer : MonoBehaviour
{
    public AudioClip death_audio;
    public AudioClip player_eliminated;
}
