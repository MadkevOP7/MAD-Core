//Obselete, replaced with PreventDuplicateLobbyCam() in LobbyManager
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class LobbyCamInstanceSwitch : MonoBehaviour
{
    /*
    public static LobbyCamInstanceSwitch instance;
    private void Awake()
    {
        if (instance == null)
        {
            instance = this;
        }
        else
        {
            Destroy(instance.gameObject);
            instance = this;
        }
    }
    */
}
