using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class LobbyWindowsStateChange : MonoBehaviour
{
    //Removed for bug fix scene transition setting back to singleplayer
    //Taken care of inside methods
   
}
