//© 2022 by MADKEV, all rights reserved

using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Trees : MonoBehaviour
{
    //reference to chunk item
    public ChunkData chunkData;
    public ObjectData objectData;
    public int health = 100;
    public int reward_id = 0;
}
