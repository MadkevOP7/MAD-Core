//© 2022 by MADKEV Studio, all rights reserved
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Mirror;
public class InfraredDetector : NetworkBehaviour
{
    [Header("Motion Detector Settings")]
    public Material red;
    public Material green;
    public Material off;
    public Material illumination;
    public GameObject topLight;
    public GameObject detectionLight;
    public GameObject illuminationLightsParent;
    public Equipment equipment;
    public Transform sensor;
    public float detection_distance = 8f;
    public LayerMask mask;
    private int cur_event; //Used to track event from Equipment
    public bool can_detect;
    public bool can_change_detection = true; //When motion detected, the detector will stay red for 6 seconds
    [SyncVar(hook = nameof(HookSyncDetection))]
    public bool detected;

    // Start is called before the first frame update
    void Start()
    {
        can_change_detection = true;
        if (equipment == null)
        {
            equipment = GetComponent<Equipment>();
        }
        cur_event = equipment.placement_event;

    }

    // Update is called once per frame
    void Update()
    {
        //Motion Detector code runs on server only to prevent owner client disconnects
        if (!isServer)
        {
            return;
        }
        if (cur_event < equipment.placement_event)
        {
            
            Refresh();
            cur_event++;
        }
        if (equipment.needRefresh)
        {
            Refresh();
            equipment.needRefresh = false;
        }
        if (can_detect)
        {

            Process();
        }
    }
    public void Process()
    {
        
        if (Physics.Raycast(sensor.position, sensor.forward, detection_distance, mask))
        {
            if (can_change_detection)
            {
                detected = true;
                can_change_detection = false;
                StartCoroutine(TimedDetectionStay());
            }
        }
        else
        {
            if (can_change_detection)
            {
                detected = false;
            }
        }
    }

    IEnumerator TimedDetectionStay()
    {
        can_change_detection = false;
        yield return new WaitForSeconds(6);
        can_change_detection = true;
    }
    public void Refresh()
    {
        if (equipment.placed)
        {
            can_detect = true;
        }
        else
        {
            can_detect = false; //Motion detector taken off
        }

    }

    public void HookSyncDetection(bool oldVal, bool newVal)
    {
        if (newVal)
        {
            //Red light, illuminate all lights
            detectionLight.GetComponent<MeshRenderer>().material = red;
            topLight.GetComponent<MeshRenderer>().material = off;
            foreach(MeshRenderer r in illuminationLightsParent.GetComponentsInChildren<MeshRenderer>())
            {
                r.material = illumination;
            }
        }
        else
        {
            //Set light to green, stop red light and illumination

            detectionLight.GetComponent<MeshRenderer>().material = off;
            topLight.GetComponent<MeshRenderer>().material = green;
            foreach (MeshRenderer r in illuminationLightsParent.GetComponentsInChildren<MeshRenderer>())
            {
                r.material = off;
            }
        }
    }
}
