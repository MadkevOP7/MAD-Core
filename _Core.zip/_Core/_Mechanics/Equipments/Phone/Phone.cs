//© 2022 by MADKEV Studio, all rights reserved
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Mirror;
using SignalRayEffect;
using UnityEngine.UI;
public class Phone : NetworkBehaviour
{
    public Equipment equipment;
    public BuildingManager building;
    //For survivors
    [Header("Phone Control")]
    public SignalRay ray;
    //Controls
    [Header("State controls")]
    public bool inUse;
    public HostMachine host_machine;
    [SyncVar(hook = nameof(hmPostHook))]
    public Vector3 hmPos;
    public GameObject tempPosOBJ;

    [Header("Customization")]

    public float damage_amount;
    public float repair_amount;

    private bool isInteracting;
    private uint playerID = 892; //892 not set yet

    public enum Mode
    {
        upload,
        build,
        destroy
    }
    public Mode mode;
    [Header("Canvas References")]
    public Sprite noSelectionImage;
    public GameObject canvas;
    public Image itemImage;
    public GameObject build_img;
    public GameObject destroy_img;
    public Text count;

    //Runtime
    GlobalInventory inventory;
    int dropEvent;
    int unEquipCount;
    private void Start()
    {
        building = GetComponent<BuildingManager>();
    }
    public void Refresh()
    {
        StartCoroutine(SetPhoneState());
    }
    IEnumerator SetPhoneState()
    {
        while (GetComponent<Equipment>().player == null)
        {
            yield return null;
        }
        bool isk = GetComponent<Equipment>().player.isKiller;
        GetComponent<PhoneScreenHandler>().UpdatePhoneStatus(isk);
    }

    [Command(requiresAuthority = false)]
    public void CMDSetHMPos(Vector3 p)
    {
        hmPos = p;
    }

    public void hmPostHook(Vector3 oldVal, Vector3 newVal)
    {
        if (tempPosOBJ != null)
        {
            tempPosOBJ.transform.position = newVal;
        }
        else
        {
            tempPosOBJ = new GameObject("TEMP RAY POS");
            tempPosOBJ.transform.position = newVal;
        }
    }

    void OnDropped()
    {
        mode = Mode.upload;
        RefreshCurrentMode();
    }

    void OnUnEquip()
    {
        mode = Mode.upload;
        RefreshCurrentMode();
    }
    private void Update()
    {
        if (equipment == null)
        {
            equipment = gameObject.GetComponent<Equipment>();
        }
        if (equipment.needRefresh)
        {
            Refresh();
            equipment.needRefresh = false;
        }
        if (dropEvent != equipment.dropped_event)
        {
            OnDropped();
            dropEvent = equipment.dropped_event;
        }
        if (unEquipCount != equipment.unEquip_event)
        {
            OnUnEquip();
            unEquipCount = equipment.unEquip_event;
        }
        if (!equipment.canUse)
        {
            return;
        }
        if (playerID == 892)
        {
            playerID = equipment.player.GetComponent<NetworkIdentity>().netId;
        }
        if (mode == Mode.upload && equipment.canUse && equipment.player != null && equipment.player.GetComponent<InteractionDetection>().selected != null && equipment.player.GetComponent<InteractionDetection>().selected.gameObject.tag == "HostMachine")
        {

            //(INPUT) Detect Input
            if (Input.GetMouseButton(0))
            {
                host_machine = equipment.player.GetComponent<InteractionDetection>().selected.GetComponent<HostMachine>();
                CMDSetHMPos(equipment.player.GetComponent<InteractionDetection>().selected.GetComponent<HostMachine>().transform.position);
                inUse = true;
            }
            if (Input.GetMouseButtonUp(0))
            {
                inUse = false;
                isInteracting = false;
            }
        }
        else
        {
            inUse = false;
            isInteracting = false;
        }

        if (inUse)
        {
            LocalInteract();
            CMDInteract();

        }
        else
        {
            LocalUnInteract();
            CMDUnInteract();
        }
        if (Input.GetMouseButtonDown(1))
        {
            switch (mode)
            {
                case Mode.upload:
                    mode = Mode.build;
                    break;

                case Mode.build:
                    mode = Mode.destroy;
                    break;
                case Mode.destroy:

                    mode = Mode.upload;
                    break;
            }
            RefreshCurrentMode();
        }
        if (mode == Mode.build)
        {
            if (inventory == null)
            {
                inventory = GlobalInventory.Instance;
            }
            UpdateSelectedItemImage();
            UpdateItemCount();
        }
    }
    public void LocalInteract()
    {
        if (equipment != null && equipment.canUse)
        {
            if (!isInteracting)
            {
                if (!equipment.player.isKiller)
                {
                    host_machine.DamageMachine(playerID);
                }
                else
                {
                    host_machine.RepairMachine(playerID);
                }
                isInteracting = true;
            }

        }
    }
    public void LocalUnInteract()
    {
        if (!equipment.player.isKiller)
        {
            if (host_machine != null)
            {
                host_machine.UnDamageMachine(playerID);
            }
        }
        else
        {
            if (host_machine != null)
            {
                host_machine.UnRepairMachine(playerID);
            }
        }
    }
    [Command(requiresAuthority = false)]
    public void CMDInteract()
    {
        RPCInteracting();
    }

    [Command(requiresAuthority = false)]
    public void CMDUnInteract()
    {
        RPCUnInteracting();
    }

    [ClientRpc]
    public void RPCInteracting()
    {
        if (tempPosOBJ == null)
        {
            tempPosOBJ = new GameObject("TEMP RAY POS");
        }
        tempPosOBJ.transform.position = hmPos;

        ray.gameObject.SetActive(true);
        if (tempPosOBJ != null)
        {
            ray.EndObject = tempPosOBJ;
            GetComponent<AudioSource>().Play();

        }
    }


    [ClientRpc]
    public void RPCUnInteracting()
    {
        Destroy(tempPosOBJ);
        tempPosOBJ = null;
        inUse = false;

        GetComponent<AudioSource>().Stop();
        ray.gameObject.SetActive(false);
    }
    private void OnDisable()
    {
        Destroy(tempPosOBJ);
        tempPosOBJ = null;
        inUse = false;

        GetComponent<AudioSource>().Stop();
        ray.gameObject.SetActive(false);
    }

    #region Build Item
    void RefreshCurrentMode()
    {
        switch (mode)
        {
            case Mode.upload:
                building.enabled = false;
                canvas.SetActive(false);
                break;

            case Mode.build:
                building.enabled = true;
                building.CleanupSelection();
                building.Action = BuildingManager.action.place;
                if (inventory == null || inventory.selected == null)
                {
                    count.text = "No Selection";
                    itemImage.sprite = noSelectionImage;
                }
                canvas.SetActive(true);
                build_img.SetActive(true);
                destroy_img.SetActive(false);
                break;

            case Mode.destroy:
                building.enabled = true;
                building.CleanupPlacementPreview();
                building.Action = BuildingManager.action.destroy;
                if (inventory == null || inventory.selected == null)
                {
                    count.text = "No Selection";
                    itemImage.sprite = noSelectionImage;
                }
                else
                {
                    count.text = "DESTROY";
                }
                canvas.SetActive(true);
                build_img.SetActive(false);
                destroy_img.SetActive(true);
                break;

        }
    }

    public void UpdateSelectedItemImage()
    {
        if (inventory == null || inventory.selected == null)
        {
            itemImage.sprite = noSelectionImage;
            return;
        }
        itemImage.sprite = GlobalBuild.Instance.previews[GlobalInventory.Instance.selected.m_name];
    }

    public void UpdateItemCount()
    {
        if (inventory == null || inventory.selected == null) return;
        count.text = inventory.selected.count.ToString();
    }
    #endregion
}
