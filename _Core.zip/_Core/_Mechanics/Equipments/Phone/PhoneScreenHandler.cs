using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Mirror;
public class PhoneScreenHandler : NetworkBehaviour
{
    public void UpdatePhoneStatus(bool iskiller)
    {
        if (iskiller)
        {
            SetPhoneRed();
            CMDSetPhoneRed();
        }
        else
        {
            setPhoneWhite();
            CMDSetPhoneWhite();
        }
    }
    private void SetPhoneRed()
    {
        Material[] materialsArray = new Material[(this.GetComponent<MeshRenderer>().materials.Length)];
        this.GetComponent<Renderer>().materials.CopyTo(materialsArray, 0);
        materialsArray[1].SetColor("_EmissionColor", Color.red);
        GetComponent<MeshRenderer>().materials = materialsArray;  
    }
    [Command(requiresAuthority =false)]
    public void CMDSetPhoneRed()
    {
        RPCSetPhoneRed();
    }
    [ClientRpc(includeOwner =false)]
    public void RPCSetPhoneRed()
    {
        SetPhoneRed();
    }


    private void setPhoneWhite()
    {
        Material[] materialsArray = new Material[(this.GetComponent<MeshRenderer>().materials.Length)];
        this.GetComponent<Renderer>().materials.CopyTo(materialsArray, 0);
        materialsArray[1].SetColor("_EmissionColor", Color.white);
        GetComponent<MeshRenderer>().materials = materialsArray;
    }

    [Command(requiresAuthority = false)]
    public void CMDSetPhoneWhite()
    {
        RPCSetPhoneWhite();
    }

    [ClientRpc(includeOwner =false)]
    public void RPCSetPhoneWhite()
    {
        setPhoneWhite();
    }
}
