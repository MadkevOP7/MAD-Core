using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Mirror;
public class EMFMeter : NetworkBehaviour
{
    public LayerMask layers;
    public float detection_distance = 16f;
    public Equipment eq;
    public AudioSource m_audio;
    [Header("Light OBJ")]
    public List<MeshRenderer> lights = new List<MeshRenderer>();
    [Header("Lights")]
    public Material light_off_material;
    public List<Material> lights_on = new List<Material>();
    [Header("Runtime")]
    public Camera cam;
    public bool is_on; //Store this on server, no sync
    public int current_level; //Store on server, no sync, use for prventing over calling light setting function
    RaycastHit[] hits;
    public Vector3 ray_offset = new Vector3(0, 0.2f, 0f);
    public int detection_Mode = 0; // 0= from this object transform.up, 1 = from player center
    // Start is called before the first frame update
    void Start()
    {
        eq = GetComponent<Equipment>();
    }

    // Update is called once per frame
    void Update()
    {
        
        if (eq == null)
        {
            return;
        }
        if (eq.needRefresh)
        {
            Refresh();
            eq.needRefresh = false;
        }
        if (eq.canUse)
        {
            if (Input.GetMouseButtonDown(1))
            {
                ServerEMF();
            }
        }

        if (isServer)
        {
            if (eq.IsPickupable())
            {
                //equipment is dropped, detection ray from transform up (forward y axis)
                detection_Mode = 0;
            }
            else
            {
                detection_Mode = 1;
            }
            ProcessEMF();
        }
        //Testing
        //SetEMFLevel(current_level);
    }

    public void Refresh()
    {
        if(eq!=null && eq.player!=null && eq.player.mainCamera != null)
        {
            cam = eq.player.mainCamera;
        }
        SetEMFLevel(0);
    }

    [Command(requiresAuthority = false)]
    public void ServerEMF()
    {
        is_on = !is_on;
    }
    //Runs on server so that emf can still detect when dropped, call from Update
    public void ProcessEMF()
    {
       
        int lv = 0;
        if (!is_on)
        {
            SetEMFLevel(0);
            return;
        }
        if (is_on)
        {
            lv = 1;
        }
        if (detection_Mode == 0)
        {
            //Detect from transform.up
            hits = Physics.RaycastAll(transform.localPosition + ray_offset, transform.up, detection_distance, layers);
        }
        else if(detection_Mode==1)
        {
            if (cam == null)
            {
                Debug.LogError("EMF failed to raycast from camera, camera is null!");
                return;
            }
            //Detect from player center point
            hits = Physics.RaycastAll(cam.ViewportPointToRay(new Vector3(0.5F, 0.5F, 0F)), detection_distance, layers);
        }
        if (hits == null)
        {
            return;
        }
        
        if (hits.Length == 0)
        {
            //No hit detected
            SetEMFLevel(lv);
            return;
        }


        //EMF Meter: Level 1 = turned on.Level 2 = found a near host machine. Level 3 = found AI ghost. Level 4 = found killer ghost, far distance.Level 5 = found killer ghost, near distance.
        //Finds first hostmachine/ghost and break
        foreach (RaycastHit h in hits)
        {
            if (h.collider.gameObject.tag == "HostMachine")
            {
                if(Distance(h.collider.transform, transform) < 8)
                {
                    lv = 2;
                    break;
                }
            }
            if (h.collider.gameObject.tag == "Ghost")
            {
                if (h.collider.gameObject.GetComponent<GhostIdentity>() != null && h.collider.gameObject.GetComponent<GhostIdentity>().respond_emf)
                {
                    if (h.collider.GetComponent<GhostAI>() != null)
                    {
                        //Level 3, Ai ghost
                        lv = 3;
                        break;
                    }
                    else
                    {
                        //Level 4 or 5, killer ghost
                        if(Distance(h.transform, transform) < 8)
                        {
                            lv = 5;
                            break;
                        }
                        else
                        {
                            lv = 4;
                            break;
                        }
                    }
                } 
            }
        }
        Debug.Log("EMF Level: " + lv);
        SetEMFLevel(lv);

    }
    [Command(requiresAuthority = false)]
    public void SetEMFLevel(int level)
    {
        if (level < 0 || level > lights.Count)
        {
            return;
        }
        if (current_level == level&&level!=0)
        {
            return;
        }
        RPCEMFLevel(level);
        current_level = level;
    }

    [ClientRpc]
    public void RPCEMFLevel(int level)
    {
        //Reset all lights to off
        foreach(MeshRenderer r in lights)
        {
            r.material = light_off_material;
        }
        for(int i=0; i<level; i++)
        {
            lights[i].material = lights_on[i];
        }

        //Audio and pitch
        float a = (level - 1) * 0.05f;
        m_audio.pitch = 1 + a;
        if (level > 1)
        {
            if (!m_audio.isPlaying)
            {
                m_audio.Play();
            }
        }
        else
        {
            m_audio.Stop();
        }
    }

    #region Helper
    public float Distance(Transform a, Transform b)
    {
        float xDiff = a.position.x - b.position.x;
        float zDiff = a.position.z - b.position.z;
        return Mathf.Sqrt((xDiff * xDiff) + (zDiff * zDiff));
    }
    public float Distance(Vector3 a, Vector3 b)
    {
        float xDiff = a.x - b.x;
        float zDiff = a.z - b.z;
        return Mathf.Sqrt((xDiff * xDiff) + (zDiff * zDiff));
    }
    #endregion
}
