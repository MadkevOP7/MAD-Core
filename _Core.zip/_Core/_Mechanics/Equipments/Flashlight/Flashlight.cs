//© 2022 by MADKEV Studio, all rights reserved
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Mirror;
public class Flashlight : NetworkBehaviour
{
    [Header("Reference")]
    public Light m_light;
    public Transform point;
    private Equipment eq;
    public AudioSource m_audio;
    public AudioClip turn_on;
    public AudioClip turn_off;
    [SyncVar(hook =nameof(HookLightStatus))]
    public bool isLightOn = true;
    private EquipmentManager equipmentManager;
    // Start is called before the first frame update
    void Start()
    {
        eq = GetComponent<Equipment>();
    }
    void Refresh()
    {
        point = NetworkClient.spawned[eq.p_follow].GetComponent<EquipmentManager>().flashlight_point;
        if (eq.canUse)
        {
            SetLightStatus(true); //Initial turn on
        }

        //Light on audio
        m_audio.Stop();
        m_audio.clip = turn_on;
        m_audio.Play();
        point = NetworkClient.spawned[eq.p_follow].GetComponent<EquipmentManager>().flashlight_point;
        equipmentManager = NetworkClient.spawned[eq.p_follow].GetComponent<EquipmentManager>();
    }
    // Update is called once per frame
    void Update()
    {
        if (eq == null || !eq.canUse)
        {
            return;
        }
        if (eq.needRefresh)
        {
            Refresh();
            eq.needRefresh = false;
        }
        if (equipmentManager != null && equipmentManager.is_OS_Mode)
        {
            return;
        }
        if (eq != null && eq.canUse&&point!=null)
        {
            m_light.transform.LookAt(point);
            CMDSyncPos(m_light.transform.localEulerAngles);
        }
        if (Input.GetMouseButtonDown(0))
        {
            SetLightStatus(!isLightOn);
        }
        if (Input.GetKeyDown(KeyCode.T))
        {
            NetworkClient.spawned[eq.p_follow].GetComponent<EquipmentManager>().UnEqipPersistent();
           
        }
    }

    [Command(requiresAuthority = false)]
    public void SetLightStatus(bool is_on)
    {
        RPCPlayAudio(is_on);
        RPCFlashlightEmission(is_on);
        isLightOn = is_on;

    }
    public void HookLightStatus(bool oldVal, bool newVal)
    {
        m_light.enabled = newVal;
    }
    [Command(requiresAuthority =false)]
    public void ServerDestroy(GameObject g)
    {
        NetworkServer.Destroy(g);
    }
    [ClientRpc]
    public void RPCPlayAudio(bool turnOn)
    {
        m_audio.Stop();
        if (turnOn)
        {
            m_audio.clip = turn_on;
        }
        else
        {
            m_audio.clip = turn_off;
        }
        m_audio.Play();
    }
    [Command(requiresAuthority = false)]
    public void CMDSyncPos(Vector3 p)
    {
        RPCSyncRotation(p);
    }
    [ClientRpc(includeOwner = false)]
    public void RPCSyncRotation(Vector3 rot)
    {
        m_light.transform.localEulerAngles = rot;
    }
    [ClientRpc]
    public void RPCFlashlightEmission(bool turn_on)
    {
        Material[] materialsArray = new Material[(this.GetComponent<MeshRenderer>().materials.Length)];
        this.GetComponent<Renderer>().materials.CopyTo(materialsArray, 0);
        materialsArray[1].EnableKeyword("_EMISSION");
        if (turn_on)
        {
            materialsArray[1].SetColor("_EmissionColor", Color.white);
        }
        else
        {
            materialsArray[1].SetColor("_EmissionColor", Color.black);
        }
        GetComponent<MeshRenderer>().materials = materialsArray;
    }
}
