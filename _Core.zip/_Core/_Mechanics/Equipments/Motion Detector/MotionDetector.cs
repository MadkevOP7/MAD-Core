//© 2022 by MADKEV Studio, all rights reserved
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Mirror;
public class MotionDetector : NetworkBehaviour
{
    [Header("Motion Detector Settings")]
    public Material red;
    public Material green;
    public Material off;
    public GameObject topLight;
    public GameObject detectionLight;
    public AudioSource m_audio;
    public Equipment equipment;
    public Transform sensor;
    public float detection_distance;
    public RaycastHit[] hits;
    private int cur_event = 0; //Used to track event from Equipment
    public bool can_detect;
    public bool can_change_detection = true; //When motion detected, the detector will stay red for 6 seconds
    [SyncVar(hook = nameof(HookSyncDetection))]
    public bool detected;

    private bool firstProcess;
    public int current_hit_count;
    // Start is called before the first frame update
    void Start()
    {
        can_change_detection = true;
        if (equipment == null)
        {
            equipment = GetComponent<Equipment>();
        }
        cur_event = equipment.placement_event;
        
    }

    // Update is called once per frame
    void Update()
    {
        //Motion Detector code runs on server only to prevent owner client disconnects
        if (!isServer)
        {
            return;
        }
        if (cur_event < equipment.placement_event)
        {
            firstProcess = false;
            Refresh();
            cur_event++;
        }
        if (equipment.needRefresh)
        {
            Refresh();
            equipment.needRefresh = false;
        }
        if (can_detect)
        {
            
            hits = Physics.RaycastAll(sensor.position, sensor.forward, detection_distance);
            Process(hits.Length);
        }
    }
    public void Process(int c)
    {
        if (!firstProcess)
        {
            current_hit_count = c;
            firstProcess = true;
            return;
        }
        if (current_hit_count != c)
        {
            if (can_change_detection)
            {
                detected = true;
                can_change_detection = false;
                StartCoroutine(TimedDetectionStay());
            }
            current_hit_count = c;
        }
        else
        {
            if (can_change_detection)
            {
                detected = false;
            }
        }
    }

    IEnumerator TimedDetectionStay()
    {
        can_change_detection = false;
        yield return new WaitForSeconds(6);
        can_change_detection = true;
    }
    public void Refresh()
    {
        if (equipment.placed)
        {
            can_detect = true;
        }
        else
        {
            can_detect = false; //Motion detector taken off
        }

    }
  
    public void HookSyncDetection(bool oldVal, bool newVal)
    {
        if (newVal)
        {
            //Start red light, continue play beep audio;
            m_audio.Play();
            detectionLight.GetComponent<MeshRenderer>().material = red;
            topLight.GetComponent<MeshRenderer>().material = off;
        }
        else
        {
            //Set light to green, pause beep audio (NO Detection)
            m_audio.Stop();
            detectionLight.GetComponent<MeshRenderer>().material = off;
            topLight.GetComponent<MeshRenderer>().material = green;
        }
    }
}
